package com.example.grocerybooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrocerybookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrocerybookingApplication.class, args);
	}

}
